const mongoose = require('mongoose');

const whatsappSchema = mongoose.Schema({
    message: String,
    name: String,
    timestamp: {type:String, default: new Date()
        .toUTCString()},
    received: Boolean
});

const Messages = mongoose.model('messageContent', whatsappSchema)
module.exports=Messages;