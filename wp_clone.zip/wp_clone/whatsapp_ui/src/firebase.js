// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyA8AHDZL4j4DRR_FRSot_72ZKT9cIXFWq8",
    authDomain: "sam-whatsapp-clone.firebaseapp.com",
    projectId: "sam-whatsapp-clone",
    storageBucket: "sam-whatsapp-clone.appspot.com",
    messagingSenderId: "830299320471",
    appId: "1:830299320471:web:b839f0c88219a5e6e4f9d2",
    measurementId: "G-CSMBD8LGD8"
  };
