import React, { useEffect, useState } from 'react';
import './App.css';
import Chat from './Chat';
import Sidebar from './Sidebar';
import Pusher from 'pusher-js';
import axios from './axios'

function App() {
  const [messages, setMessages] = useState([])
  const [name, setName] = useState("")
  const [open, setOpen] = useState(false)
 
  useEffect(() => {
    axios.get('/message/sync')
      .then(response => {
        console.log(response.data);
        setMessages(response.data)
      })
  }, []);

  console.log(messages);

  useEffect(() => {
    const pusher = new Pusher('c706e2897311e260e7cb', {
      cluster: 'eu'
    });

    const channel = pusher.subscribe('messages');
    channel.bind('inserted', (newMessages)=> {
      // alert(JSON.stringify(newMessages));
      setMessages([...messages, newMessages])
    });
    return () => {
      channel.unbind_all();
      channel.unsubscribe();
    }
  }, [messages])
  const registerName = () => {
    localStorage.setItem('name',name)
    setOpen(true)
  }
  if (name=="" || open==false){
    return(
      <div>
      <input value={name} onChange={e=> setName(e.target.value)} placeholder="Type a message.."
      type="text"/>
      <button onClick={registerName}>open</button>
      </div>
    )
  }else if(open==true){

    return (
      <div className="app">
        <div className="app__body">
          <Sidebar/>
          <Chat messages={messages} />
        </div>
        
      </div>
    );
  }
}

export default App;
