import { Avatar } from '@material-ui/core'
import React from 'react'
import "./SidebarChat.css"
function SidebarChat() {
    return (
        <div className="sidebarChat">
            <Avatar/>
            <div className="sidebar_info">
                <h4>Room name</h4>
                <p>this is last message</p>
            </div>
        </div>
    )
}

export default SidebarChat
